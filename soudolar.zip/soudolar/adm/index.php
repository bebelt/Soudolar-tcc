<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/5b9d82b6ee.js" crossorigin="anonymous"></script>
   
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soudolar | Adminstração</title>
</head>
<style>
    @import url("https://fonts.googleapis.com/css?family=Amaranth");
    @import url('https://fonts.cdnfonts.com/css/glacial-indifference-2');
    :root{
        --white: #f9f9f9;
        --blue: #1f3a93;
        --yellow:  #3498db;
        --lblue: #87ceeb;
    }
     body{
        margin: 0;
        background-repeat: no-repeat;
        background-size: contain;
        background-attachment: fixed;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;

    }
    .row{
        align-items: center;
        align-self: center;
        justify-content: center;
        display: flex;

    }
    #col{
        background-color: #f9f9f9;
        border-radius: 20px;
        border:none;
        
        box-shadow: rgba(0, 0, 0, 0.25) 0px 14px 28px, rgba(0, 0, 0, 0.22) 0px 10px 10px;
        height: 80vh;
    }
    .adm, .row{
        font-family: 'Amaranth';
        
    }
        .adm{
            font-size: 1.5em;
            margin-top: 10%;
           
        }
    .row{
        height: 26%;
    }
    .input{
        background-color: #1f3a93;
        padding: 20px 25px 10px 25px;
        border: none;
        width: 60%;
        border-radius: 10px;

    }
   
    .title{
        font-family: 'Amaranth';
        font-size: 2em;
        margin-right: 3%;
    }
    .cont{
        margin-top: 10%;
    }
    .es{
        margin-top: 15%;
      
    }
    .submit{
        color:#fff ;
        font-size: 1.3em;
        background-color: #1f3a93;
        border: none;
        transition: 0.2s;
    }
    .submit:hover{
        transform: scale(1.1);
        transition: 0.2s;
        cursor: pointer;
    }
    @media screen and (max-width: 1300px) {
  body{
        height: 100%;
        margin: 0;
        background-image: url(view/img/painel.jpg);
        background-repeat: no-repeat;
        background-size: auto;
        background-attachment: initial;
  }
  .input{
        background-color: var(--lblue);
        padding: 10px 15px 10px 15px;
        border: none;
        width: 80%;
        border-radius: 50px;

    }
    .adm{
            font-size: 1.3em;
            margin-top: 10%;
           
        }
    }
</style>
<script>
      function updateElementClass() {
      const element = document.getElementById('col');

      if (window.innerWidth <= 1000) {  // Tamanho da tela abaixo de 768 pixels
        element.classList.remove('col-5');
        element.classList.add('col-10');
      } else {
        element.classList.remove('col-10');
        element.classList.add('col-5');
      }
    }

    window.addEventListener('load', updateElementClass);
    window.addEventListener('resize', updateElementClass);


    </script>
<body>
    <div class="container">
        <div class="row">
            <div class="col-5" id="col">
                <div class="row adm">
                   <span class="title">Área Restrita </span>   
                </div>
                
                <form action="controller/controller.php" method="post" name="loginform">
                    <input type="hidden" name="loginsenha" value="1">
                <div class="row">
                    <input type="text" name="login" class="input" rquired placeholder="Digite seu e-mail">
                </div>
                <br>
                <div class="row">
                    <input type="password" name="senha" class="input" required placeholder="Digite sua senha">
                </div>
                <div class="row cont">
                    <button class="submit" type="submit">Continuar</button>
                </div>
                </form>
            </div>
        </div>
        </div>
        <?php
if(isset($_REQUEST["msg"])){
	$cod = $_REQUEST["msg"];
	require_once "model/msg.php";
	echo "<script>alert('" . $MSG[$cod] . "');</script>";
    unset($cod);
}
?>
</body>
</html>