<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastramento | sou do lar</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://kit.fontawesome.com/04c7887f31.js" crossorigin="anonymous"></script> <!--kit fontawesome-->
    <script src="hide.js"></script>
    <script src="forgotpass.js"></script>
</head>
<body>
    <header>
        <div class="menu">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-2">
                       <a href="../index.php"> <i class="fa-solid-fa-arrow-left-fa-xl" style="color: #edeff2;"></i> </a>
                    </div><!--fecha col-2-->
                    <div class="col-10">
                      <a href="../index.php"> <img src="img/logo_nome.png" alt=""> </a>
                    </div><!--fecha col-10-->
                </div><!--fecha row-->
            </div> <!--fecha container-fluid-->
        </div> <!--fecha slider-->
    </header>
    <main>
        <div class="formulario"> 
            <p> Iniciar sessão</p>
            <div id="form_estrutura">
                <div id="login-box">
                <div class="input-group">
                    <input type="email" id="email" name="email" required class="input">
                    <label for="email" class="input-label"> E-mail </label><br><br><br>
                </div>
                <div class="input-group">
                    <i class="bi bi-eye-fill" id="btn-senha" onclick="mostrarSenha()"></i>
                    <input type="password" id="senha" name="senha" required class="input">
                    <label for="password" class="input-label">Senha</label><br><br><br>
                </div>
                <button class="esqueceu" id="openModalBtn">Esqueceu sua senha?</button>
                <button type="submit" class="form-submit-button"><a href="minhaconta.php">Entrar</a></button>
                </div>
                <p class="possui"> <a href="cadastramento.php"> Não possui cadastro? Faça agora </a></p>
            </div>
        </div>
        <!--MODAL-->
        <div id="myModal" class="modal">
            <div class="modal-content">
                <span class="close-x">&times;</span>
                <h2>Recuperação de Senha</h2>
                <p class="recuperar-text">Identifique-se para receber um e-mail com as instruções e o link para criar uma nova senha.</p>
                <form class="password-reset" id="passwordResetForm">
                    <input class="input-email" type="email" id="email" name="email" required class="input-email">
                    <label class="input-label-email" for="email">E-mail:</label>
                    <button class="button-enviar" type="submit">Enviar</button>
                </form>
            </div>
        </div>
    </main>
</body>
</html>