<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sou do Lar</title>
  <link rel="stylesheet" href="src/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
  <link rel="stylesheet" href="css/produto.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> <!--css bootstrap-->
  <script src="https://kit.fontawesome.com/04c7887f31.js" crossorigin="anonymous"></script> <!--kit fontawesome-->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" ></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" ></script>
</head>
<header >
  <div class="menu fixed-top">
      <div class="container-fluid">
          <div class="row">
              <div class="col-12">
                  <div class="logo">
                      <a href="../index.php"><img class="logo_img" src="img/logo_nome.png"></a>
                  </div> <!--fecha logo-->
                  
                  <nav class="links">
                      <ul class="nav">
                          <li class="lista"><a href="limpeza.php">Limpeza</a></li>
                          <li class="lista"><a href="sacaria.php">Sacaria</a></li>
                          <li class="lista"><a href="utilidades.php">Utilidades</a></li>
                          <li class="lista"><a href="#">Sobre</a></li>
                      </ul>
                  </nav> <!--fecha links-->
                  
                  
                  <div class="search">
                      <form class="form-inline my-2 my-xs-0" style=" position: absolute; top: 25%; margin-left: 4%;">
                          <input class="form-control mr-sm-2" style=" background-color: #f5f5f5d0; width: 75%; border: 1px solid #f5f5f5; " type="search" placeholder="Pesquisar" >
                          <button class="btn btn-outline-secondary my-2 my-sm-0" style= "color:#f5f5f5; width:20%; border: 1px solid #f5f5f5d0;" type="submit"><i class="fa-solid fa-magnifying-glass" style="color: #f5f5f5; margin-left: 2%;"></i></button>
                        </form>
                  </div> <!--fecha search-->
                  
                  <div class="icon">
                     <a href="login.php"><i class="fa-solid fa-user fa-xl" class="fa-solid fa-user fa-xl" style="color: #f5f5f5;   position: absolute; top: 40%; left: 90%;"></i></a>
                     <a href="cart.html"> <!--Icon carrinho-->
                    <i class="fa-solid fa-cart-shopping fa-xl"  style="color: #f5f5f5; position: absolute; top:40%; left: 93%;"></i>
                    <div id="cartAmount" class="cartAmount">0</div>
                  </a>
                  </div> <!--fecha icon-->
              </div> <!--fecha col-12-->
          </div><!--fecha row-->
      </div> <!--fecha container-fluid-->
  </div><!--fecha menu-->
</header>
<body style="background-color: rgb(228, 228, 228);">
 

  <div class="shop" id="shop"></div>

  <footer> 
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 cFooter ">
                <div class="footer-logo">
                    <a href="../index.php"><img class="footer-img" src="img/logo_nome.png"></a>
                    <p class="slogan">Cuidados para sua casa</p>
                    <form name="n" method="post" action="#">
                        <input type="submit" value="fale conosco" class="botao"/>
                        </form>
                  </div> <!--fecha footer-logo-->

<div class="footer-nav">
    <ul class="footer">
        <li class="footer"><a href="limpeza.php">Limpeza</a></li>
        <li class="footer"><a href="sacaria.php">Sacaria</a></li>
        <li class="footer"><a href="utilidades.php">Utilidades</a></li>
        <li class="footer"><a href="#">Sobre</a></li>
    </ul>
</div> <!--fecha footer-nav-->

                <div class="footer-icon">
                    <a href="https://wa.me/5511941920047"><i class="fa-brands fa-whatsapp fa-xl" style="color: #f5f5f5; line-height: 55px; margin-left: 50px; margin-top: -5px;"></i></a> <br>
                    <a href="https://www.instagram.com/soudo_lar/"><i class="fa-brands fa-instagram fa-xl" style="color: #f5f5f5; line-height: 55px; margin-left: 50px;"></i></a> <br>
                    <a href="mailto:soudolar1@gmail.com"><i class="fa-regular fa-envelope fa-xl" style="color: #f5f5f5; line-height: 55px; margin-left: 50px;"></i></a> 
                </div> <!--fecha footer-icon-->
                
            </div> <!--fecha cFooter-->
        </div> <!--fecha row-->
    </div> <!--fecha container do footer-->
</footer>
</body>
<script src="src/Data.js"></script>
<script src="src/main.js"></script>

</html>