<!DOCTYPE html>
<html lang="en">
<?php

session_start();

if(isset($_SESSION['USER-ID'])){
    
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha conta | Sou do Lar</title>
    <link rel="stylesheet" href="css/minhaconta.css">
    <script>
        function enableEdit(inputId) {
            var inputElement = document.getElementById(inputId);
            inputElement.removeAttribute('readonly');
        }

        function saveChanges() {
            // adicionar o código para salvar as alterações no servidor
            // enviar uma requisição AJAX para um backend que irá processar as alterações e salvar os novos dados no banco de dados.
            alert('Alterações salvas com sucesso!');
        }
    </script>
</head>
<body>
    <header>
        <div class="coluna1">
            <div class="menu fixed-top">
                <div class="logo">
                    <a href="#"><img class="logo_img" src="logo_nome.png"></a>
                </div> <!--fecha logo--> <br>
                <nav class="links">
                    <ul class="nav">
                        <li class="lista"><a href="#">Minha conta</a></li>
                        <li class="lista"><a href="sacaria.php">Meus pedidos</a></li>
                        <li class="lista"><a href="utilidades.php">Historico</a></li>
        
                        <li class="lista" style="margin-top: 77%;"><a href="">Excluir conta</a></li>
                        <li class="lista"style="margin-top: -5%;"><a href="">Sair</a></li>
                        <br><br><br>
                    </ul>
                </nav> <!--fecha links-->
            </div><!--fecha menu-->
        </div>

        <div class="coluna2">
            <p> Editar dados cadastrados</p>
            <div class="caixa">
                <br>
                <div class="input-group">
                    <label for="nome" class="input-label">Nome completo:</label>
                    <input type="text" id="nome" name="nome" required class="input" style="margin-left: 1%;">
                    <br><br><br>
                </div>

                <div class="input-group">
                    <label for="tel" class="input-label">Telefone:</label>
                    <input type="tel" id="tel" name="telefone" required class="input" style="margin-left: 7%;" readonly>
                    <button class="button-edit" onclick="enableEdit('tel')">Editar</button> <br><br><br>
                </div>
            
                <div class="input-group">
                    <label for="email" class="input-label">Email:</label>
                    <input type="email" id="email" name="email" required class="input" style="margin-left: 9%;" readonly>
                    <button class="button-edit" onclick="enableEdit('email')">Editar</button> <br><br><br>
                </div>
            
                <div class="input-group">
                    <label for="senha" class="input-label">Senha:</label>
                    <input type="password" id="senha" name="senha" required class="input" style="margin-left: 9%;" readonly>
                    <button class="button-edit" onclick="enableEdit('senha')">Editar</button> <br><br><br>
                </div>
            
                <div class="input-group">
                    <label for="confSenha" class="input-label">Confirmar senha:</label>
                    <input type="password" id="confSenha" name="confSenha" required class="input" style="margin-left: 1%;" readonly>
                    <button class="button-edit" onclick="enableEdit('confSenha')">Editar</button> <br><br><br>
            
                    <button onclick="saveChanges()" style="cursor: pointer; margin-left: 32%; width: 30%; height: 15%; font-size: 1.5em; display: block;text-align: center; padding: 14px 16px; text-decoration: none; border-radius: 20px; background-color: #1f3a93; color: #fff;">Salvar alterações</button> <br>
                </div> <!--fecha caixa-->
                <script>
        function ExecutaLogout() {
    var resp = confirm('Deseja sair do sistema?');
    if (resp == true) {
        location.href = "cliente_logout.php";
    } else {
        return null;
    }
}
</script>
            </body>
            <?php
if(isset($_REQUEST["msg"])){
	$cod = $_REQUEST["msg"];
	require_once "../model/msg.php";
	echo "<script>alert('" . $MSG[$cod] . "');</script>";
    unset($cod);

}
?>
            </html>
            <?php } else{ header("Location: login.php?fase=2"); }?>