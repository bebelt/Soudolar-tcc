<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cadastramento</title>
    <link rel="stylesheet" href="css/cadastramento.css">
    <script src="https://kit.fontawesome.com/04c7887f31.js" crossorigin="anonymous"></script> <!--kit fontawesome-->
</head>
<body>
    <header>
        <div class="menu">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-2">
                       <a href="login.php"> <i class="fa-solid fa-arrow-left fa-xl" style="color: #edeff2;"></i> </a>
                    </div><!--fecha col-2-->
                    <div class="col-10">
                      <a href="../index.php"> <img src="img/logo_nome.png" alt=""> </a>
                    </div><!--fecha col-10-->
                </div><!--fecha row-->
            </div> <!--fecha container-fluid-->
        </div> <!--fecha slider-->
    </header>
    <main>
        <div class="formulario">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="form_estrutura">
                            <div class="faca-box">
                                <p class="faca"> Faça seu cadastro</p>
                                <p class="form"> Preencha os campos com suas informações</p> <br><br><br>
                                <div class="input-group">
                                    <input type="text" id="nome" name="nome" required class="input">
                                    <label for="nome" class="input-label">Nome completo</label> <br><br><br>
                                </div>

                                <div class="input-group">
                                    <input type="tel" id="tel" name="telefone" required class="input">
                                    <label for="tel" class="input-label">Telefone</label> <br><br><br>
                                </div>

                                <div class="input-group">
                                    <input type="text" id="cpf" name="cpf" required class="input">
                                    <label for="cpf" class="input-label">CPF</label> <br><br><br>
                                </div>

                                <div class="input-group">
                                    <input type="e-mail" id="e-mail" name="e-mail" required class="input">
                                    <label for="email" class="input-label">Email</label> <br><br><br>
                                </div>

                                <div class="input-group">
                                    <input type="password" id="senha" name="senha" required class="input">
                                    <label for="senha" class="input-label">Senha</label> <br><br><br>
                                </div>

                                <div class="input-group">
                                    <input type="password" id="senha" name="senha" required class="input">
                                    <label for="senha" class="input-label">Confirmar senha</label> <br><br><br>
                                </div>
                                <button type="submit" class="form-submit-button">Enviar</button>
                            </div>
                        </div>
                    </div><!--fecha col-12-->
                </div><!--fecha row-->
            </div> <!--fecha container-fluid-->
        </div> <!--fecha formulario-->
        
    </main>
</body>
</html>