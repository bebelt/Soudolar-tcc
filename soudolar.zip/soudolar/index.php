<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sou do lar</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="view/source/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> <!--css bootstrap-->
    <script src="https://kit.fontawesome.com/04c7887f31.js" crossorigin="anonymous"></script> <!--kit fontawesome-->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" ></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>
<body>
    <header >
        <div class="menu fixed-top">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="logo">
                            <a href="adm/index.php"><img class="logo_img" src="view/img/logo_nome.png"></a>
                        </div> <!--fecha logo-->
                        
                        <nav class="links">
                            <ul class="nav">
                                <li class="lista"><a href="view/limpeza.php">Limpeza</a></li>
                                <li class="lista"><a href="view/sacaria.php">Sacaria</a></li>
                                <li class="lista"><a href="view/utilidades.php">Utilidades</a></li>
                                <li class="lista"><a href="#">Sobre</a></li>
                            </ul>
                        </nav> <!--fecha links-->   
                        
                        
                        <div class="search">
                            <form class="form-inline my-2 my-xs-0" style=" position: absolute; top: 25%; margin-left: 4%;">
                                <input class="form-control mr-sm-2" style=" background-color: #f5f5f5d0; width: 75%; border: 1px solid #f5f5f5; " type="search" placeholder="Pesquisar" >
                                <button class="btn btn-outline-secondary my-2 my-sm-0" style= "color:#f5f5f5; width:20%; border: 1px solid #f5f5f5d0;" type="submit"><i class="fa-solid fa-magnifying-glass" style="color: #f5f5f5; margin-left: 2%;"></i></button>
                              </form>
                        </div> <!--fecha search-->
                        
                        <div class="icon">
                            <a href="view/login.php"><i class="fa-solid fa-user fa-xl" class="fa-solid fa-user fa-xl" style="color: #f5f5f5;   position: absolute; top: 40%; left: 90%;"></i></a>
                            <a href="view/cart.html"> <!--Icon carrinho-->
                           <i class="fa-solid fa-cart-shopping fa-xl"  style="color: #f5f5f5; position: absolute; top:40%; left: 93%;"></i>
                           <div id="cartAmount" class="cartAmount">0</div>
                         </a>
                         </div> <!--fecha icon-->
                    </div> <!--fecha col-12-->
                </div><!--fecha row-->
            </div> <!--fecha container-fluid-->
        </div><!--fecha menu-->
    </header>

    <main>
        <div class="slider">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                              <img class="d-block w-100" src="view/img/limpeza.jpg" alt="Primeiro Slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="view/img/sacaria.jpg" alt="Segundo Slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="view/img/utilidades.jpg" alt="Terceiro Slide">
                            </div>
                          </div>
                          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Anterior</span>
                          </a>
                          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Próximo</span>
                          </a>
        </div> <!--fecha slider-->


        <p class="titulo" style="margin-left: 270px;">Mais Vendidos</p>

        <div class="shop" id="shop">
            
        </div>


        <div class="loc">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <p class="titulo_produto">Onde nos encontrar?</p> 
                        <p class="endereco"> Av.Carlos Barbosa Santos, 1614.</p>
  
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.4555112137336!2d-46.67947042371953!3d-23.76678846917314!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce48a46bfb515f%3A0xc3f62e94a668b638!2sAv.%20Carlos%20Barbosa%20Santos%2C%201614%20-%20Jardim%20Novo%20Jau%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004852-515!5e0!3m2!1spt-BR!2sbr!4v1693518704460!5m2!1spt-BR!2sbr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  
                        <div id="number">
                        <i class="fa-solid fa-phone fa-2x"><p class="number">(11) 5505-2373 <span class="detalhe">|</span></p></i> 
      
                        <i class="fa-brands fa-instagram fa-2x"><p class="number">@soudo_lar</p></i> 
     
                        </div>
                    </div><!--fecha col-12-->
                </div><!--fecha row-->
            </div> <!--fecha container-fluid-->
        </div> <!--fecha slider-->
    </SECTION>
    </main>
    <footer> 
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 cFooter ">
                    <div class="footer-logo">
                        <img class="footer-img" src="view/img/logo_nome.png">
                        <p class="slogan">Cuidados para sua casa</p>
                        <form name="n" method="post" action="#">
                            <input type="submit" value="fale conosco" class="botao"/>
                            </form>
                      </div> <!--fecha footer-logo-->
    
    <div class="footer-nav">
        <ul class="footer">
            <li class="footer"><a href="#">Limpeza</a></li>
            <li class="footer"><a href="#">Sacaria</a></li>
            <li class="footer"><a href="#">Utilidades</a></li>
            <li class="footer"><a href="#">Sobre</a></li>
        </ul>
    </div> <!--fecha footer-nav-->
    
                    <div class="footer-icon">
                        <a href="https://wa.me/5511941920047"><i class="fa-brands fa-whatsapp fa-xl" style="color: #f5f5f5; line-height: 55px; margin-left: 50px; margin-top: -5px;"></i></a> <br>
                        <a href="https://www.instagram.com/soudo_lar/"><i class="fa-brands fa-instagram fa-xl" style="color: #f5f5f5; line-height: 55px; margin-left: 50px;"></i></a> <br>
                        <a href="mailto:soudolar1@gmail.com"><i class="fa-regular fa-envelope fa-xl" style="color: #f5f5f5; line-height: 55px; margin-left: 50px;"></i></a> 
                    </div> <!--fecha footer-icon-->
                    
                </div> <!--fecha cFooter-->
            </div> <!--fecha row-->
        </div> <!--fecha container do footer-->
    </footer>
</body>
<script src="view/source/dataindex.js"></script>
<script src="view/source/mainindex.js"></script>
<script src="view/sourcetwo/data-promocoes.js"></script>
<script src="view/sourcetwo/main-promocoes.js"></script>
</html>